# Avoyd
# This camera can buffer, freeze and make your camera magical, for example, if a color is spotted on the cam, it will replace with the background! (current features so far...)
