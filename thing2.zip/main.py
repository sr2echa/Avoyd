#import sys
#sys.path.append('./Avoyd')
#import setup
import sys
sys.path.append('./Avoyd/ui')
import amogusus
